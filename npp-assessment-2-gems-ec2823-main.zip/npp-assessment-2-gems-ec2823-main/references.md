In this file, list any sources you used to assist you with this coursework, including generative AI tools, such as ChatGPT.

```python
https://caremad.io/posts/2013/07/setup-vs-requirement/ #explanation of the difference between setup.py and requirements.txt
```

```python
https://numpy.org/doc/stable/reference/generated/numpy.full_like.html #using numpy documentation for different purposes
```

```python
https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.quiver.html #using matplotlib documentation for different purposes
```

```python
https://www.youtube.com/watch?v=O_OeWxpnUc0 #video about matplotlib 
```

```python
https://www.youtube.com/watch?v=0yRBQjZifEA #video about quiver matplotlib function
```

```python
https://stackoverflow.com/questions/18691084/what-does-1-mean-in-numpy-reshape #reshape() information
```

```python
https://chat.openai.com/ #I've used chat gpt dozens of times to debug my code,
                        #find functions in the libraries with their explanations and get ideas.
                        # For example, I found the quiver function with chatgpt

```

```python
https://www.youtube.com/watch?v=SOsfKLMKO08 #video about magnetic-skyrmion
```

```python

```
